package org.igniterealtime.openfire.exampleplugin;

/**
 * Instances of this class are only to be referenced by the plugin mentioned in the class name. This intends to ensure
 * that the call has not been loaded yet (which is helpful to debug class loading intricacies)
 */
public class ProvidedBy_Node_A_C_ReferencedBy_Node_A_C_D_Destroy
{
    boolean loaded = false;

    public ProvidedBy_Node_A_C_ReferencedBy_Node_A_C_D_Destroy()
    {
        loaded = true;
    }
}
