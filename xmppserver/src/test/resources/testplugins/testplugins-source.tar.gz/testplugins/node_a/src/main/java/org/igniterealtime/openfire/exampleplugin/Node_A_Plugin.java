package org.igniterealtime.openfire.exampleplugin;

import org.jivesoftware.openfire.container.Plugin;
import org.jivesoftware.openfire.container.PluginManager;

import java.io.File;

/**
 * A plugin that lives in a hierarchy where it has two children and two grandchildren.
 *
 * The init and destroy methods reference classes provided by parent plugins. It is assumed that those classes are not
 * referenced before (thus the reference should trigger a class loader to look up the class). This is useful for class
 * loader testing.
 */
public class Node_A_Plugin implements Plugin
{
    public void initializePlugin(PluginManager pluginManager, File pluginDirectory)
    {
        System.out.println("Initializing " + getClass().getSimpleName() + ".");
    }

    public void destroyPlugin()
    {
        System.out.println("Destroying " + getClass().getSimpleName() + ".");
    }
}
