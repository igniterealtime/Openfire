package org.igniterealtime.openfire.exampleplugin;

import org.jivesoftware.openfire.container.Plugin;
import org.jivesoftware.openfire.container.PluginManager;

import java.io.File;

/**
 * A plugin that lives in a hierarchy where it has two children and a parent.
 *
 * The init and destroy methods reference classes provided by parent plugins. It is assumed that those classes are not
 * referenced before (thus the reference should trigger a class loader to look up the class). This is useful for class
 * loader testing.
 */
public class Node_A_C_Plugin implements Plugin
{
    public void initializePlugin(PluginManager pluginManager, File pluginDirectory)
    {
        System.out.println("Initializing " + getClass().getSimpleName() + "." +
            " Parent plugin class reference: " + ProvidedBy_Node_A_ReferencedBy_Node_A_C_Init.class  + " (its class loader: " + ProvidedBy_Node_A_ReferencedBy_Node_A_C_Init.class.getClassLoader() + ").");
    }

    public void destroyPlugin()
    {
        // Reference different class than what was referenced in `initialize` in order to maximize the chance that class loading is triggered.
        System.out.println("Destroying " + getClass().getSimpleName() + "." +
            " Parent plugin class reference: " + ProvidedBy_Node_A_ReferencedBy_Node_A_C_Destroy.class  + " (its class loader: " + ProvidedBy_Node_A_ReferencedBy_Node_A_C_Destroy.class.getClassLoader() + ").");
    }
}
